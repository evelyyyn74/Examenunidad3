package com.utez.catalogo_inventario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CatalogoInventarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(CatalogoInventarioApplication.class, args);
	}

}
