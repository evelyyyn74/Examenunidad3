package com.utez.catalogo_inventario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatalogoInventarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
